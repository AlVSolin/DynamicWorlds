// Fill out your copyright notice in the Description page of Project Settings.


#include "BuildingsManager.h"

#include "GlobalVariables.h"

#include "Components/HierarchicalInstancedStaticMeshComponent.h"


// Sets default values
ABuildingsManager::ABuildingsManager()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = false;

	HISMC = CreateDefaultSubobject<UHierarchicalInstancedStaticMeshComponent>(TEXT("HISMC"));
	RootComponent = HISMC;

}

// Called when the game starts or when spawned
void ABuildingsManager::BeginPlay()
{
	Super::BeginPlay();

	SetActorLocation(FVector(0, 0, 0));

	SetMeshScale();

	GetWorld()->GetTimerManager().SetTimer(TimerToUpdateTextRendersRotation, this, &ABuildingsManager::UpdateTextRendersRotation, 0.2f, true);
}

// Called every frame
void ABuildingsManager::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

ABuildingsManager::Building::Building(int32 WorldIndex, FVector Location, FRotator Rotation, TSharedPtr<Building> SupplyBuilding)
{
	this->WorldIndex = WorldIndex;
	this->Location = Location;
	this->Rotation = Rotation;
	this->SupplyBuilding = SupplyBuilding;
}

void ABuildingsManager::IncreaseResources(TSharedPtr<Building> TargetBuilding)
{
	if (TargetBuilding->CurResources < MaxResources)
	{
		++TargetBuilding->CurResources;
		if (TargetBuilding->BuildingType == 2)
		{
			++PortalCommonResources;
			for (const TSharedPtr<Building>& B : TargetBuilding->ParentManager->Buildings)
			{
				B->CurResources = PortalCommonResources;
				B->TextRender->SetText(FText::AsNumber(B->CurResources));
			}
		}
		TargetBuilding->TextRender->SetText(FText::AsNumber(TargetBuilding->CurResources));
	}
}

void ABuildingsManager::DecreaseResources(TSharedPtr<Building> TargetBuilding)
{
	if (TargetBuilding->CurResources > 0)
	{
		--TargetBuilding->CurResources;
		if (TargetBuilding->BuildingType == 2)
		{
			--PortalCommonResources;
			for (const TSharedPtr<Building>& B : TargetBuilding->ParentManager->Buildings)
			{
				B->CurResources = PortalCommonResources;
				B->TextRender->SetText(FText::AsNumber(B->CurResources));
			}
		}
		TargetBuilding->TextRender->SetText(FText::AsNumber(TargetBuilding->CurResources));
	}
}

void ABuildingsManager::CreateBuilding(int32 WorldIndex, FVector Location, FRotator Rotation, TSharedPtr<Building> SupplyBuilding)
{
	TSharedPtr<Building> NewBuilding = MakeShared<Building>(WorldIndex, Location, Rotation, SupplyBuilding);
	NewBuilding->ParentManager = StartParentManager;
	NewBuilding->CurResources = StartResources;
	NewBuilding->BuildingType = StartBuildingType;
	if (StartBuildingType == 2)
	{
		NewBuilding->CurResources = PortalCommonResources;
	}
	Buildings.Add(NewBuilding);
	ShowBuildingVisualization(Location, Rotation);

	UTextRenderComponent* TextRender = NewObject<UTextRenderComponent>(this);
	TextRender->RegisterComponent();
	TextRender->AttachToComponent(RootComponent, FAttachmentTransformRules::KeepRelativeTransform);
	TextRender->SetWorldLocation(Location + FVector(0, 0, 120));
	TextRender->SetHorizontalAlignment(EHTA_Center);
	TextRender->SetTextRenderColor(FColor::Green);
	TextRender->SetText(FText::AsNumber(NewBuilding->CurResources));

	NewBuilding->TextRender = TextRender;
}

void ABuildingsManager::DrawHISMCByWorld(int32 TargetWorldIndex)
{
	HISMC->ClearInstances();
    for (const TSharedPtr<Building>& Building : Buildings)
    {
        if (Building->WorldIndex == TargetWorldIndex)
        {
            ShowBuildingVisualization(Building->Location, Building->Rotation);
			Building->TextRender->SetVisibility(true);
        }
		else
		{
			Building->TextRender->SetVisibility(false);
		}
    }
}

void ABuildingsManager::ShowBuildingVisualization(FVector Location, FRotator Rotation)
{
	FTransform Transform;
	Transform.SetLocation(Location);
	Transform.SetRotation(Rotation.Quaternion());
	Transform.SetScale3D(Scale);

	HISMC->AddInstance(Transform);
}

void ABuildingsManager::SetMeshScale()
{
	FBox BoundingBox = HISMC->GetStaticMesh()->GetBoundingBox();
	FVector MeshSize = BoundingBox.GetSize();

	Scale = Scale / MeshSize;
}

void ABuildingsManager::UpdateTextRendersRotation()
{
    APlayerController* PlayerController = GetWorld()->GetFirstPlayerController();
    if (PlayerController)
    {
        FVector PlayerCameraLocation;
        FRotator PlayerCameraRotation;
        PlayerController->GetPlayerViewPoint(PlayerCameraLocation, PlayerCameraRotation);

        for (const TSharedPtr<Building>& Building : Buildings)
        {
            if (Building && Building->TextRender)
            {
                FVector Direction = (PlayerCameraLocation - Building->TextRender->GetComponentLocation()).GetSafeNormal();
                FRotator NewRotation = Direction.Rotation();
                
                Building->TextRender->SetWorldRotation(NewRotation);
            }
        }
    }
}
