// Fill out your copyright notice in the Description page of Project Settings.


#include "TransmitterBuildingsManager.h"

#include "GlobalVariables.h"


ATransmitterBuildingsManager::ATransmitterBuildingsManager()
{
    StartResources = 0;
    StartBuildingType = 1;
    StartParentManager = this;
}

void ATransmitterBuildingsManager::BeginPlay()
{
    Super::BeginPlay();

    GetWorld()->GetTimerManager().SetTimer(TimerToMoveResources, this, &ATransmitterBuildingsManager::MoveResources, 1.0f, true);
}

void ATransmitterBuildingsManager::MoveResources()
{
    for (TSharedPtr<Building> Building : Buildings)
    {
        if (Building->SupplyBuilding && Building->CurResources < MaxResources && Building->SupplyBuilding->CurResources > 0)
        {
            IncreaseResources(Building);
            DecreaseResources(Building->SupplyBuilding);
        }
    }
}
