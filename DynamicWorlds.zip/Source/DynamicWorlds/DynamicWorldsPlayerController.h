// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "BuildingsManager.h" // Невозможно использовать Forward Declaration из-за вложенного класса Building.
#include "Components/TextRenderComponent.h"

#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "DynamicWorldsPlayerController.generated.h"

/**
 * 
 */
UCLASS()
class DYNAMICWORLDS_API ADynamicWorldsPlayerController : public APlayerController
{
	GENERATED_BODY()

public:
	ADynamicWorldsPlayerController();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

protected:

	virtual void SetupInputComponent() override;

	void MoveForward(float Value);
    void MoveRight(float Value);
    void Turn(float Rate);
    void LookUp(float Rate);

	void PrevWorld();
	void NextWorld();
	void CreateSourceBuilding();
	void CreateTransmitterBuilding();
	void CreatePortalBuilding();

	class ASourceBuildingsManager* SourceBuildingsManager;
	class ATransmitterBuildingsManager* TransmitterBuildingsManager;
	class APortalBuildingsManager* PortalBuildingsManager;

	int32 CurWorld = 0;
	int32 NumberOfWorlds = 1;

	void GetSpawnLocationAndRotation(FVector& Location, FRotator& Rotation);

	void DrawWorld(int32 WorldIndex);

	TSharedPtr<ABuildingsManager::Building> FindNearestBuilding(FVector Location);

	UTextRenderComponent* CurWorldTextRender;

	void UpdateTextRendersRotation();
};
