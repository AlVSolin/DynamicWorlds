// Fill out your copyright notice in the Description page of Project Settings.


#include "DynamicWorldsPlayerController.h"

#include "GlobalVariables.h"

#include "Kismet/GameplayStatics.h"
#include "Components/HierarchicalInstancedStaticMeshComponent.h"

#include "SourceBuildingsManager.h"
#include "TransmitterBuildingsManager.h"
#include "PortalBuildingsManager.h"

#include "DrawDebugHelpers.h"

int32 PortalCommonResources = 0;


ADynamicWorldsPlayerController::ADynamicWorldsPlayerController()
{
    PrimaryActorTick.bCanEverTick = true;

    SourceBuildingsManager = Cast<ASourceBuildingsManager>
    (
        UGameplayStatics::GetActorOfClass(GetWorld(), ASourceBuildingsManager::StaticClass())
    );

    TransmitterBuildingsManager = Cast<ATransmitterBuildingsManager>
    (
        UGameplayStatics::GetActorOfClass(GetWorld(), ATransmitterBuildingsManager::StaticClass())
    );

    PortalBuildingsManager = Cast<APortalBuildingsManager>
    (
        UGameplayStatics::GetActorOfClass(GetWorld(), APortalBuildingsManager::StaticClass())
    );
}

void ADynamicWorldsPlayerController::BeginPlay()
{
    PortalCommonResources = 0;
    CurWorldTextRender = NewObject<UTextRenderComponent>(SourceBuildingsManager);
	CurWorldTextRender->RegisterComponent();
	CurWorldTextRender->AttachToComponent(SourceBuildingsManager->GetRootComponent(), FAttachmentTransformRules::KeepRelativeTransform);
	CurWorldTextRender->SetWorldLocation(FVector(1000, 0, 500));
    CurWorldTextRender->SetWorldSize(200.0f);
	CurWorldTextRender->SetHorizontalAlignment(EHTA_Center);
	CurWorldTextRender->SetTextRenderColor(FColor::Red);
	CurWorldTextRender->SetText(FText::AsNumber(CurWorld));
}

void ADynamicWorldsPlayerController::Tick(float DeltaTime)
{
    UpdateTextRendersRotation();
}

void ADynamicWorldsPlayerController::SetupInputComponent()
{
    Super::SetupInputComponent();

    InputComponent->BindAxis("MoveForward", this, &ADynamicWorldsPlayerController::MoveForward);
    InputComponent->BindAxis("MoveRight", this, &ADynamicWorldsPlayerController::MoveRight);
    InputComponent->BindAxis("Turn", this, &ADynamicWorldsPlayerController::Turn);
    InputComponent->BindAxis("LookUp", this, &ADynamicWorldsPlayerController::LookUp);

    InputComponent->BindAction("PrevWorld", IE_Pressed, this, &ADynamicWorldsPlayerController::PrevWorld);
    InputComponent->BindAction("NextWorld", IE_Pressed, this, &ADynamicWorldsPlayerController::NextWorld);
    InputComponent->BindAction("CreateSource", IE_Pressed, this, &ADynamicWorldsPlayerController::CreateSourceBuilding);
    InputComponent->BindAction("CreateTransmitter", IE_Pressed, this, &ADynamicWorldsPlayerController::CreateTransmitterBuilding);
    InputComponent->BindAction("CreatePortal", IE_Pressed, this, &ADynamicWorldsPlayerController::CreatePortalBuilding);
}

void ADynamicWorldsPlayerController::PrevWorld()
{
    if (CurWorld == 0) return;

    --CurWorld;

    CurWorldTextRender->SetText(FText::AsNumber(CurWorld));

    DrawWorld(CurWorld);
}

void ADynamicWorldsPlayerController::NextWorld()
{
    ++CurWorld;

	CurWorldTextRender->SetText(FText::AsNumber(CurWorld));

    DrawWorld(CurWorld);
}

void ADynamicWorldsPlayerController::CreateSourceBuilding()
{
    FVector Location;
    FRotator Rotation;

    GetSpawnLocationAndRotation(Location, Rotation);

    SourceBuildingsManager->CreateBuilding(CurWorld, Location, Rotation, nullptr);
}

void ADynamicWorldsPlayerController::CreateTransmitterBuilding()
{
    FVector Location;
    FRotator Rotation;

    GetSpawnLocationAndRotation(Location, Rotation);

    TransmitterBuildingsManager->CreateBuilding(CurWorld, Location, Rotation, FindNearestBuilding(Location));
}

void ADynamicWorldsPlayerController::CreatePortalBuilding()
{
    FVector Location;
    FRotator Rotation;

    GetSpawnLocationAndRotation(Location, Rotation);

    PortalBuildingsManager->CreateBuilding(CurWorld, Location, Rotation, FindNearestBuilding(Location));
}

void ADynamicWorldsPlayerController::GetSpawnLocationAndRotation(FVector& Location, FRotator& Rotation)
{
    GetPlayerViewPoint(Location, Rotation);

    FVector ForwardVector = Rotation.Vector();

    Location.Z = 0;
    ForwardVector.Z = 0;
    ForwardVector.Normalize();
    Location = Location + 300.f * ForwardVector;
    Rotation = FRotator(0.f, Rotation.Yaw, 0.f);
}

void ADynamicWorldsPlayerController::DrawWorld(int32 WorldIndex)
{
    SourceBuildingsManager->DrawHISMCByWorld(WorldIndex);
    TransmitterBuildingsManager->DrawHISMCByWorld(WorldIndex);
    PortalBuildingsManager->DrawHISMCByWorld(WorldIndex);
    GetPawn()->SetActorLocation(FVector(0, 0, 300));
}

TSharedPtr<ABuildingsManager::Building> ADynamicWorldsPlayerController::FindNearestBuilding(FVector Location)
{
    TSharedPtr<ABuildingsManager::Building> NearestBuilding = nullptr;
    float MinDistance = FMath::Square(15000.f); // Диагональ карты 100 на 100 метров не превосходит 150 метров. Для производительности сравнивать будем квадраты расстояний.

    for (const TSharedPtr<ABuildingsManager::Building>& Building : SourceBuildingsManager->Buildings)
    {
        if (Building->WorldIndex == CurWorld)
        {
            float CurDistance = FVector::DistSquared(Location, Building->Location);
            if (CurDistance < MinDistance)
            {
                MinDistance = CurDistance;
                NearestBuilding = Building;
            }
        }
    }

    for (const TSharedPtr<ABuildingsManager::Building>& Building : TransmitterBuildingsManager->Buildings)
    {
        if (Building->WorldIndex == CurWorld)
        {
            float CurDistance = FVector::DistSquared(Location, Building->Location);
            if (CurDistance < MinDistance)
            {
                MinDistance = CurDistance;
                NearestBuilding = Building;
            }
        }
    }

    for (const TSharedPtr<ABuildingsManager::Building>& Building : PortalBuildingsManager->Buildings)
    {
        if (Building->WorldIndex == CurWorld)
        {
            float CurDistance = FVector::DistSquared(Location, Building->Location);
            if (CurDistance < MinDistance)
            {
                MinDistance = CurDistance;
                NearestBuilding = Building;
            }
        }
    }

    return NearestBuilding;
}

void ADynamicWorldsPlayerController::UpdateTextRendersRotation()
{
    APlayerController* PlayerController = GetWorld()->GetFirstPlayerController();
    if (PlayerController)
    {
        FVector PlayerCameraLocation;
        FRotator PlayerCameraRotation;
        PlayerController->GetPlayerViewPoint(PlayerCameraLocation, PlayerCameraRotation);

        FVector Direction = (PlayerCameraLocation - CurWorldTextRender->GetComponentLocation()).GetSafeNormal();
        FRotator NewRotation = Direction.Rotation();
        
        CurWorldTextRender->SetWorldRotation(NewRotation);
    }
}

void ADynamicWorldsPlayerController::MoveForward(float Value)
{
    if (Value != 0.0f)
    {
        FVector Forward = GetPawn()->GetActorForwardVector();
        GetPawn()->AddMovementInput(Forward, Value);
    }
}

void ADynamicWorldsPlayerController::MoveRight(float Value)
{
    if (Value != 0.0f)
    {
        FVector Right = GetPawn()->GetActorRightVector();
        GetPawn()->AddMovementInput(Right, Value);
    }
}

void ADynamicWorldsPlayerController::Turn(float Rate)
{
    AddYawInput(Rate);
}

void ADynamicWorldsPlayerController::LookUp(float Rate)
{
    AddPitchInput(Rate);
}