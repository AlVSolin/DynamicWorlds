// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "BuildingsManager.h"
#include "SourceBuildingsManager.generated.h"

/**
 * 
 */
UCLASS()
class DYNAMICWORLDS_API ASourceBuildingsManager : public ABuildingsManager
{
	GENERATED_BODY()

public:	
	ASourceBuildingsManager();

};
