// Fill out your copyright notice in the Description page of Project Settings.


#include "PortalBuildingsManager.h"

#include "GlobalVariables.h"

APortalBuildingsManager::APortalBuildingsManager()
{
    StartBuildingType = 2;
    StartParentManager = this;
}

void APortalBuildingsManager::BeginPlay()
{
    Super::BeginPlay();

    GetWorld()->GetTimerManager().SetTimer(TimerToMoveResources, this, &APortalBuildingsManager::MoveResources, 1.0f, true);
}

void APortalBuildingsManager::MoveResources()
{
    for (TSharedPtr<Building> Building : Buildings)
    {
        if (Building->SupplyBuilding && Building->CurResources < MaxResources && Building->SupplyBuilding->CurResources > 0)
        {
            IncreaseResources(Building);
            DecreaseResources(Building->SupplyBuilding);
        }
    }
}