// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "BuildingsManager.h"
#include "TransmitterBuildingsManager.generated.h"

/**
 * 
 */
UCLASS()
class DYNAMICWORLDS_API ATransmitterBuildingsManager : public ABuildingsManager
{
	GENERATED_BODY()
	
public:	
	ATransmitterBuildingsManager();

protected:

	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

protected:

	FTimerHandle TimerToMoveResources;

	void MoveResources();

};
