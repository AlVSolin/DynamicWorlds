// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Components/TextRenderComponent.h"

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "BuildingsManager.generated.h"

UCLASS()
class DYNAMICWORLDS_API ABuildingsManager : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	ABuildingsManager();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

// ---

public:

	class Building
	{
	public:
		Building(int32 WorldIndex, FVector Location, FRotator Rotation, TSharedPtr<Building> SupplyBuilding);
		int32 WorldIndex;
		FVector Location;
		FRotator Rotation;
		int32 CurResources = 0;
		TSharedPtr<Building> SupplyBuilding = nullptr;
		int32 BuildingType = 0;
		ABuildingsManager* ParentManager;

		UTextRenderComponent* TextRender;
	};

	void IncreaseResources(TSharedPtr<Building> Building);
	void DecreaseResources(TSharedPtr<Building> Building);

	void CreateBuilding(int32 WorldIndex, FVector Location, FRotator Rotation, TSharedPtr<Building> SupplyBuilding);

	TArray<TSharedPtr<Building>> Buildings;

	UPROPERTY(VisibleAnywhere)
    class UHierarchicalInstancedStaticMeshComponent* HISMC;

	void DrawHISMCByWorld(int32 WorldIndex);

	ABuildingsManager* StartParentManager;

protected:
	void ShowBuildingVisualization(FVector Location, FRotator Rotation);

	FVector Scale = FVector(100.f, 100.f, 100.f);

	void SetMeshScale();

	int32 StartResources;
	int32 StartBuildingType;
	int32 MaxResources = 100;

	void UpdateTextRendersRotation();

	FTimerHandle TimerToUpdateTextRendersRotation;

private:

};
