// Fill out your copyright notice in the Description page of Project Settings.


#include "SourceBuildingsManager.h"

#include "GlobalVariables.h"

ASourceBuildingsManager::ASourceBuildingsManager()
{
    StartResources = 100;
    StartBuildingType = 0;
    StartParentManager = this;
}