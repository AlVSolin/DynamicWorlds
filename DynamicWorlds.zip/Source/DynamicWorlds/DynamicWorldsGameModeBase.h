// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "DynamicWorldsGameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class DYNAMICWORLDS_API ADynamicWorldsGameModeBase : public AGameModeBase
{
	GENERATED_BODY()
	
};
