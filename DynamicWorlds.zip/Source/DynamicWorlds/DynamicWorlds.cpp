// Copyright Epic Games, Inc. All Rights Reserved.

#include "DynamicWorlds.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, DynamicWorlds, "DynamicWorlds" );
